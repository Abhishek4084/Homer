﻿namespace RadarStub
{
    partial class FormRadarStub
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.buttonSend = new System.Windows.Forms.Button();
            this.textBoxLat = new System.Windows.Forms.TextBox();
            this.textBoxLong = new System.Windows.Forms.TextBox();
            this.textBoxbearing = new System.Windows.Forms.TextBox();
            this.textBoxGroundSpeed = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.labelLat = new System.Windows.Forms.Label();
            this.labelLong = new System.Windows.Forms.Label();
            this.labelHeading = new System.Windows.Forms.Label();
            this.textBoxHeading = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.textBoxRateOfTurn = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.textBoxLat1 = new System.Windows.Forms.TextBox();
            this.textBoxLat5 = new System.Windows.Forms.TextBox();
            this.textBoxLat4 = new System.Windows.Forms.TextBox();
            this.textBoxLat3 = new System.Windows.Forms.TextBox();
            this.textBoxLat2 = new System.Windows.Forms.TextBox();
            this.textBoxLong2 = new System.Windows.Forms.TextBox();
            this.textBoxLong3 = new System.Windows.Forms.TextBox();
            this.textBoxLong4 = new System.Windows.Forms.TextBox();
            this.textBoxLong5 = new System.Windows.Forms.TextBox();
            this.textBoxLong1 = new System.Windows.Forms.TextBox();
            this.comboBoxIntensity = new System.Windows.Forms.ComboBox();
            this.textBoxHeight2 = new System.Windows.Forms.TextBox();
            this.textBoxHeight3 = new System.Windows.Forms.TextBox();
            this.textBoxHeight4 = new System.Windows.Forms.TextBox();
            this.textBoxHeight5 = new System.Windows.Forms.TextBox();
            this.textBoxHeight1 = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.textBoxHeight7 = new System.Windows.Forms.TextBox();
            this.textBoxHeight8 = new System.Windows.Forms.TextBox();
            this.textBoxHeight9 = new System.Windows.Forms.TextBox();
            this.textBoxHeight10 = new System.Windows.Forms.TextBox();
            this.textBoxHeight6 = new System.Windows.Forms.TextBox();
            this.textBoxLong7 = new System.Windows.Forms.TextBox();
            this.textBoxLong8 = new System.Windows.Forms.TextBox();
            this.textBoxLong9 = new System.Windows.Forms.TextBox();
            this.textBoxLong10 = new System.Windows.Forms.TextBox();
            this.textBoxLong6 = new System.Windows.Forms.TextBox();
            this.textBoxLat7 = new System.Windows.Forms.TextBox();
            this.textBoxLat8 = new System.Windows.Forms.TextBox();
            this.textBoxLat9 = new System.Windows.Forms.TextBox();
            this.textBoxLat10 = new System.Windows.Forms.TextBox();
            this.textBoxLat6 = new System.Windows.Forms.TextBox();
            this.comboBoxCloudId = new System.Windows.Forms.ComboBox();
            this.label13 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // buttonSend
            // 
            this.buttonSend.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonSend.Location = new System.Drawing.Point(152, 194);
            this.buttonSend.Name = "buttonSend";
            this.buttonSend.Size = new System.Drawing.Size(75, 23);
            this.buttonSend.TabIndex = 0;
            this.buttonSend.Text = "Send";
            this.buttonSend.UseVisualStyleBackColor = true;
            this.buttonSend.Click += new System.EventHandler(this.buttonSend_Click);
            // 
            // textBoxLat
            // 
            this.textBoxLat.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxLat.Location = new System.Drawing.Point(140, 36);
            this.textBoxLat.Name = "textBoxLat";
            this.textBoxLat.Size = new System.Drawing.Size(100, 20);
            this.textBoxLat.TabIndex = 1;
            this.textBoxLat.Text = "45";
            // 
            // textBoxLong
            // 
            this.textBoxLong.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxLong.Location = new System.Drawing.Point(140, 62);
            this.textBoxLong.Name = "textBoxLong";
            this.textBoxLong.Size = new System.Drawing.Size(100, 20);
            this.textBoxLong.TabIndex = 2;
            this.textBoxLong.Text = "45";
            // 
            // textBoxbearing
            // 
            this.textBoxbearing.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxbearing.Location = new System.Drawing.Point(140, 88);
            this.textBoxbearing.Name = "textBoxbearing";
            this.textBoxbearing.Size = new System.Drawing.Size(100, 20);
            this.textBoxbearing.TabIndex = 3;
            this.textBoxbearing.Text = "0";
            // 
            // textBoxGroundSpeed
            // 
            this.textBoxGroundSpeed.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxGroundSpeed.Location = new System.Drawing.Point(140, 114);
            this.textBoxGroundSpeed.Name = "textBoxGroundSpeed";
            this.textBoxGroundSpeed.Size = new System.Drawing.Size(100, 20);
            this.textBoxGroundSpeed.TabIndex = 4;
            this.textBoxGroundSpeed.Text = "555";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(57, 36);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(76, 13);
            this.label1.TabIndex = 5;
            this.label1.Text = "Lat (degree)";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(48, 62);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(86, 13);
            this.label2.TabIndex = 6;
            this.label2.Text = "Long (degree)";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(35, 88);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(101, 13);
            this.label3.TabIndex = 7;
            this.label3.Text = "Bearing (degree)";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(10, 114);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(130, 13);
            this.label4.TabIndex = 8;
            this.label4.Text = "Ground Speed (kmph)";
            // 
            // labelLat
            // 
            this.labelLat.AutoSize = true;
            this.labelLat.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelLat.Location = new System.Drawing.Point(9, 238);
            this.labelLat.Name = "labelLat";
            this.labelLat.Size = new System.Drawing.Size(56, 13);
            this.labelLat.TabIndex = 9;
            this.labelLat.Text = "Initial lat";
            // 
            // labelLong
            // 
            this.labelLong.AutoSize = true;
            this.labelLong.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelLong.Location = new System.Drawing.Point(9, 252);
            this.labelLong.Name = "labelLong";
            this.labelLong.Size = new System.Drawing.Size(70, 13);
            this.labelLong.TabIndex = 10;
            this.labelLong.Text = "Initial Long";
            // 
            // labelHeading
            // 
            this.labelHeading.AutoSize = true;
            this.labelHeading.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelHeading.Location = new System.Drawing.Point(9, 266);
            this.labelHeading.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.labelHeading.Name = "labelHeading";
            this.labelHeading.Size = new System.Drawing.Size(89, 13);
            this.labelHeading.TabIndex = 11;
            this.labelHeading.Text = "Initial Heading";
            this.labelHeading.Click += new System.EventHandler(this.label5_Click);
            // 
            // textBoxHeading
            // 
            this.textBoxHeading.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxHeading.Location = new System.Drawing.Point(140, 138);
            this.textBoxHeading.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.textBoxHeading.Name = "textBoxHeading";
            this.textBoxHeading.Size = new System.Drawing.Size(100, 20);
            this.textBoxHeading.TabIndex = 12;
            this.textBoxHeading.Text = "0";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(76, 135);
            this.label6.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(54, 13);
            this.label6.TabIndex = 13;
            this.label6.Text = "Heading";
            // 
            // textBoxRateOfTurn
            // 
            this.textBoxRateOfTurn.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxRateOfTurn.Location = new System.Drawing.Point(140, 161);
            this.textBoxRateOfTurn.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.textBoxRateOfTurn.Name = "textBoxRateOfTurn";
            this.textBoxRateOfTurn.Size = new System.Drawing.Size(100, 20);
            this.textBoxRateOfTurn.TabIndex = 14;
            this.textBoxRateOfTurn.Tag = "";
            this.textBoxRateOfTurn.Text = "0";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(56, 158);
            this.label5.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(79, 13);
            this.label5.TabIndex = 15;
            this.label5.Text = "Rate of Turn";
            // 
            // textBoxLat1
            // 
            this.textBoxLat1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxLat1.Location = new System.Drawing.Point(309, 62);
            this.textBoxLat1.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.textBoxLat1.Name = "textBoxLat1";
            this.textBoxLat1.Size = new System.Drawing.Size(76, 20);
            this.textBoxLat1.TabIndex = 16;
            this.textBoxLat1.Text = "44.1";
            // 
            // textBoxLat5
            // 
            this.textBoxLat5.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxLat5.Location = new System.Drawing.Point(309, 161);
            this.textBoxLat5.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.textBoxLat5.Name = "textBoxLat5";
            this.textBoxLat5.Size = new System.Drawing.Size(76, 20);
            this.textBoxLat5.TabIndex = 17;
            this.textBoxLat5.Text = "44.5";
            // 
            // textBoxLat4
            // 
            this.textBoxLat4.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxLat4.Location = new System.Drawing.Point(309, 136);
            this.textBoxLat4.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.textBoxLat4.Name = "textBoxLat4";
            this.textBoxLat4.Size = new System.Drawing.Size(76, 20);
            this.textBoxLat4.TabIndex = 18;
            this.textBoxLat4.Text = "44.5";
            this.textBoxLat4.TextChanged += new System.EventHandler(this.textBoxLat4_TextChanged);
            // 
            // textBoxLat3
            // 
            this.textBoxLat3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxLat3.Location = new System.Drawing.Point(309, 111);
            this.textBoxLat3.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.textBoxLat3.Name = "textBoxLat3";
            this.textBoxLat3.Size = new System.Drawing.Size(76, 20);
            this.textBoxLat3.TabIndex = 19;
            this.textBoxLat3.Text = "44.4";
            // 
            // textBoxLat2
            // 
            this.textBoxLat2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxLat2.Location = new System.Drawing.Point(309, 88);
            this.textBoxLat2.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.textBoxLat2.Name = "textBoxLat2";
            this.textBoxLat2.Size = new System.Drawing.Size(76, 20);
            this.textBoxLat2.TabIndex = 20;
            this.textBoxLat2.Text = "44.2";
            // 
            // textBoxLong2
            // 
            this.textBoxLong2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxLong2.Location = new System.Drawing.Point(388, 88);
            this.textBoxLong2.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.textBoxLong2.Name = "textBoxLong2";
            this.textBoxLong2.Size = new System.Drawing.Size(76, 20);
            this.textBoxLong2.TabIndex = 25;
            this.textBoxLong2.Text = "45.1";
            // 
            // textBoxLong3
            // 
            this.textBoxLong3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxLong3.Location = new System.Drawing.Point(388, 111);
            this.textBoxLong3.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.textBoxLong3.Name = "textBoxLong3";
            this.textBoxLong3.Size = new System.Drawing.Size(76, 20);
            this.textBoxLong3.TabIndex = 24;
            this.textBoxLong3.Text = "45.1";
            // 
            // textBoxLong4
            // 
            this.textBoxLong4.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxLong4.Location = new System.Drawing.Point(388, 136);
            this.textBoxLong4.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.textBoxLong4.Name = "textBoxLong4";
            this.textBoxLong4.Size = new System.Drawing.Size(76, 20);
            this.textBoxLong4.TabIndex = 23;
            this.textBoxLong4.Text = "45.2";
            // 
            // textBoxLong5
            // 
            this.textBoxLong5.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxLong5.Location = new System.Drawing.Point(388, 161);
            this.textBoxLong5.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.textBoxLong5.Name = "textBoxLong5";
            this.textBoxLong5.Size = new System.Drawing.Size(76, 20);
            this.textBoxLong5.TabIndex = 22;
            this.textBoxLong5.Text = "45.3";
            // 
            // textBoxLong1
            // 
            this.textBoxLong1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxLong1.Location = new System.Drawing.Point(388, 62);
            this.textBoxLong1.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.textBoxLong1.Name = "textBoxLong1";
            this.textBoxLong1.Size = new System.Drawing.Size(76, 20);
            this.textBoxLong1.TabIndex = 21;
            this.textBoxLong1.Text = "45.0";
            // 
            // comboBoxIntensity
            // 
            this.comboBoxIntensity.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboBoxIntensity.FormattingEnabled = true;
            this.comboBoxIntensity.Items.AddRange(new object[] {
            "1",
            "2",
            "3"});
            this.comboBoxIntensity.Location = new System.Drawing.Point(561, 62);
            this.comboBoxIntensity.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.comboBoxIntensity.Name = "comboBoxIntensity";
            this.comboBoxIntensity.Size = new System.Drawing.Size(75, 21);
            this.comboBoxIntensity.TabIndex = 26;
            // 
            // textBoxHeight2
            // 
            this.textBoxHeight2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxHeight2.Location = new System.Drawing.Point(468, 88);
            this.textBoxHeight2.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.textBoxHeight2.Name = "textBoxHeight2";
            this.textBoxHeight2.Size = new System.Drawing.Size(76, 20);
            this.textBoxHeight2.TabIndex = 31;
            this.textBoxHeight2.Text = "3.005";
            // 
            // textBoxHeight3
            // 
            this.textBoxHeight3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxHeight3.Location = new System.Drawing.Point(468, 111);
            this.textBoxHeight3.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.textBoxHeight3.Name = "textBoxHeight3";
            this.textBoxHeight3.Size = new System.Drawing.Size(76, 20);
            this.textBoxHeight3.TabIndex = 30;
            this.textBoxHeight3.Text = "3.006";
            // 
            // textBoxHeight4
            // 
            this.textBoxHeight4.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxHeight4.Location = new System.Drawing.Point(468, 136);
            this.textBoxHeight4.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.textBoxHeight4.Name = "textBoxHeight4";
            this.textBoxHeight4.Size = new System.Drawing.Size(76, 20);
            this.textBoxHeight4.TabIndex = 29;
            this.textBoxHeight4.Text = "3.004";
            // 
            // textBoxHeight5
            // 
            this.textBoxHeight5.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxHeight5.Location = new System.Drawing.Point(468, 161);
            this.textBoxHeight5.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.textBoxHeight5.Name = "textBoxHeight5";
            this.textBoxHeight5.Size = new System.Drawing.Size(76, 20);
            this.textBoxHeight5.TabIndex = 28;
            this.textBoxHeight5.Text = "3.1";
            // 
            // textBoxHeight1
            // 
            this.textBoxHeight1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxHeight1.Location = new System.Drawing.Point(468, 62);
            this.textBoxHeight1.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.textBoxHeight1.Name = "textBoxHeight1";
            this.textBoxHeight1.Size = new System.Drawing.Size(76, 20);
            this.textBoxHeight1.TabIndex = 27;
            this.textBoxHeight1.Text = "3";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(334, 33);
            this.label7.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(25, 13);
            this.label7.TabIndex = 32;
            this.label7.Text = "Lat";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(406, 33);
            this.label8.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(35, 13);
            this.label8.TabIndex = 33;
            this.label8.Text = "Long";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(488, 33);
            this.label9.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(44, 13);
            this.label9.TabIndex = 34;
            this.label9.Text = "Height";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(575, 33);
            this.label10.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(55, 13);
            this.label10.TabIndex = 35;
            this.label10.Text = "Intensity";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(171, 7);
            this.label11.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(54, 13);
            this.label11.TabIndex = 36;
            this.label11.Text = "AC Data";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(442, 7);
            this.label12.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(70, 13);
            this.label12.TabIndex = 37;
            this.label12.Text = "Cloud Data";
            // 
            // textBoxHeight7
            // 
            this.textBoxHeight7.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxHeight7.Location = new System.Drawing.Point(468, 211);
            this.textBoxHeight7.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.textBoxHeight7.Name = "textBoxHeight7";
            this.textBoxHeight7.Size = new System.Drawing.Size(76, 20);
            this.textBoxHeight7.TabIndex = 58;
            this.textBoxHeight7.Text = "3.005";
            // 
            // textBoxHeight8
            // 
            this.textBoxHeight8.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxHeight8.Location = new System.Drawing.Point(468, 234);
            this.textBoxHeight8.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.textBoxHeight8.Name = "textBoxHeight8";
            this.textBoxHeight8.Size = new System.Drawing.Size(76, 20);
            this.textBoxHeight8.TabIndex = 57;
            this.textBoxHeight8.Text = "3.006";
            // 
            // textBoxHeight9
            // 
            this.textBoxHeight9.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxHeight9.Location = new System.Drawing.Point(468, 259);
            this.textBoxHeight9.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.textBoxHeight9.Name = "textBoxHeight9";
            this.textBoxHeight9.Size = new System.Drawing.Size(76, 20);
            this.textBoxHeight9.TabIndex = 56;
            this.textBoxHeight9.Text = "3.004";
            // 
            // textBoxHeight10
            // 
            this.textBoxHeight10.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxHeight10.Location = new System.Drawing.Point(468, 284);
            this.textBoxHeight10.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.textBoxHeight10.Name = "textBoxHeight10";
            this.textBoxHeight10.Size = new System.Drawing.Size(76, 20);
            this.textBoxHeight10.TabIndex = 55;
            this.textBoxHeight10.Text = "3.1";
            // 
            // textBoxHeight6
            // 
            this.textBoxHeight6.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxHeight6.Location = new System.Drawing.Point(468, 185);
            this.textBoxHeight6.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.textBoxHeight6.Name = "textBoxHeight6";
            this.textBoxHeight6.Size = new System.Drawing.Size(76, 20);
            this.textBoxHeight6.TabIndex = 54;
            this.textBoxHeight6.Text = "3";
            // 
            // textBoxLong7
            // 
            this.textBoxLong7.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxLong7.Location = new System.Drawing.Point(388, 211);
            this.textBoxLong7.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.textBoxLong7.Name = "textBoxLong7";
            this.textBoxLong7.Size = new System.Drawing.Size(76, 20);
            this.textBoxLong7.TabIndex = 53;
            this.textBoxLong7.Text = "45.2";
            // 
            // textBoxLong8
            // 
            this.textBoxLong8.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxLong8.Location = new System.Drawing.Point(388, 234);
            this.textBoxLong8.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.textBoxLong8.Name = "textBoxLong8";
            this.textBoxLong8.Size = new System.Drawing.Size(76, 20);
            this.textBoxLong8.TabIndex = 52;
            this.textBoxLong8.Text = "45.1";
            // 
            // textBoxLong9
            // 
            this.textBoxLong9.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxLong9.Location = new System.Drawing.Point(388, 259);
            this.textBoxLong9.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.textBoxLong9.Name = "textBoxLong9";
            this.textBoxLong9.Size = new System.Drawing.Size(76, 20);
            this.textBoxLong9.TabIndex = 51;
            this.textBoxLong9.Text = "45.1";
            // 
            // textBoxLong10
            // 
            this.textBoxLong10.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxLong10.Location = new System.Drawing.Point(388, 284);
            this.textBoxLong10.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.textBoxLong10.Name = "textBoxLong10";
            this.textBoxLong10.Size = new System.Drawing.Size(76, 20);
            this.textBoxLong10.TabIndex = 50;
            this.textBoxLong10.Text = "45.0";
            // 
            // textBoxLong6
            // 
            this.textBoxLong6.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxLong6.Location = new System.Drawing.Point(388, 185);
            this.textBoxLong6.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.textBoxLong6.Name = "textBoxLong6";
            this.textBoxLong6.Size = new System.Drawing.Size(76, 20);
            this.textBoxLong6.TabIndex = 49;
            this.textBoxLong6.Text = "45.2";
            // 
            // textBoxLat7
            // 
            this.textBoxLat7.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxLat7.Location = new System.Drawing.Point(309, 211);
            this.textBoxLat7.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.textBoxLat7.Name = "textBoxLat7";
            this.textBoxLat7.Size = new System.Drawing.Size(76, 20);
            this.textBoxLat7.TabIndex = 48;
            this.textBoxLat7.Text = "44.3";
            // 
            // textBoxLat8
            // 
            this.textBoxLat8.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxLat8.Location = new System.Drawing.Point(309, 234);
            this.textBoxLat8.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.textBoxLat8.Name = "textBoxLat8";
            this.textBoxLat8.Size = new System.Drawing.Size(76, 20);
            this.textBoxLat8.TabIndex = 47;
            this.textBoxLat8.Text = "44.2";
            // 
            // textBoxLat9
            // 
            this.textBoxLat9.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxLat9.Location = new System.Drawing.Point(309, 259);
            this.textBoxLat9.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.textBoxLat9.Name = "textBoxLat9";
            this.textBoxLat9.Size = new System.Drawing.Size(76, 20);
            this.textBoxLat9.TabIndex = 46;
            this.textBoxLat9.Text = "44.1";
            // 
            // textBoxLat10
            // 
            this.textBoxLat10.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxLat10.Location = new System.Drawing.Point(309, 284);
            this.textBoxLat10.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.textBoxLat10.Name = "textBoxLat10";
            this.textBoxLat10.Size = new System.Drawing.Size(76, 20);
            this.textBoxLat10.TabIndex = 45;
            this.textBoxLat10.Text = "44.0";
            // 
            // textBoxLat6
            // 
            this.textBoxLat6.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxLat6.Location = new System.Drawing.Point(309, 185);
            this.textBoxLat6.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.textBoxLat6.Name = "textBoxLat6";
            this.textBoxLat6.Size = new System.Drawing.Size(76, 20);
            this.textBoxLat6.TabIndex = 44;
            this.textBoxLat6.Text = "44.4";
            // 
            // comboBoxCloudId
            // 
            this.comboBoxCloudId.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboBoxCloudId.FormattingEnabled = true;
            this.comboBoxCloudId.Items.AddRange(new object[] {
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "10"});
            this.comboBoxCloudId.Location = new System.Drawing.Point(561, 106);
            this.comboBoxCloudId.Name = "comboBoxCloudId";
            this.comboBoxCloudId.Size = new System.Drawing.Size(73, 21);
            this.comboBoxCloudId.TabIndex = 59;
            this.comboBoxCloudId.SelectedIndexChanged += new System.EventHandler(this.comboBoxCloudId_SelectedIndexChanged);
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(575, 90);
            this.label13.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(54, 13);
            this.label13.TabIndex = 60;
            this.label13.Text = "Cloud Id";
            // 
            // FormRadarStub
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(650, 320);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.comboBoxCloudId);
            this.Controls.Add(this.textBoxHeight7);
            this.Controls.Add(this.textBoxHeight8);
            this.Controls.Add(this.textBoxHeight9);
            this.Controls.Add(this.textBoxHeight10);
            this.Controls.Add(this.textBoxHeight6);
            this.Controls.Add(this.textBoxLong7);
            this.Controls.Add(this.textBoxLong8);
            this.Controls.Add(this.textBoxLong9);
            this.Controls.Add(this.textBoxLong10);
            this.Controls.Add(this.textBoxLong6);
            this.Controls.Add(this.textBoxLat7);
            this.Controls.Add(this.textBoxLat8);
            this.Controls.Add(this.textBoxLat9);
            this.Controls.Add(this.textBoxLat10);
            this.Controls.Add(this.textBoxLat6);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.textBoxHeight2);
            this.Controls.Add(this.textBoxHeight3);
            this.Controls.Add(this.textBoxHeight4);
            this.Controls.Add(this.textBoxHeight5);
            this.Controls.Add(this.textBoxHeight1);
            this.Controls.Add(this.comboBoxIntensity);
            this.Controls.Add(this.textBoxLong2);
            this.Controls.Add(this.textBoxLong3);
            this.Controls.Add(this.textBoxLong4);
            this.Controls.Add(this.textBoxLong5);
            this.Controls.Add(this.textBoxLong1);
            this.Controls.Add(this.textBoxLat2);
            this.Controls.Add(this.textBoxLat3);
            this.Controls.Add(this.textBoxLat4);
            this.Controls.Add(this.textBoxLat5);
            this.Controls.Add(this.textBoxLat1);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.textBoxRateOfTurn);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.textBoxHeading);
            this.Controls.Add(this.labelHeading);
            this.Controls.Add(this.labelLong);
            this.Controls.Add(this.labelLat);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.textBoxGroundSpeed);
            this.Controls.Add(this.textBoxbearing);
            this.Controls.Add(this.textBoxLong);
            this.Controls.Add(this.textBoxLat);
            this.Controls.Add(this.buttonSend);
            this.Name = "FormRadarStub";
            this.Text = "Radar Stub 1.0";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Form1_FormClosing);
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button buttonSend;
        private System.Windows.Forms.TextBox textBoxLat;
        private System.Windows.Forms.TextBox textBoxLong;
        private System.Windows.Forms.TextBox textBoxbearing;
        private System.Windows.Forms.TextBox textBoxGroundSpeed;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label labelLat;
        private System.Windows.Forms.Label labelLong;
        private System.Windows.Forms.Label labelHeading;
        private System.Windows.Forms.TextBox textBoxHeading;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox textBoxRateOfTurn;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox textBoxLat1;
        private System.Windows.Forms.TextBox textBoxLat5;
        private System.Windows.Forms.TextBox textBoxLat4;
        private System.Windows.Forms.TextBox textBoxLat3;
        private System.Windows.Forms.TextBox textBoxLat2;
        private System.Windows.Forms.TextBox textBoxLong2;
        private System.Windows.Forms.TextBox textBoxLong3;
        private System.Windows.Forms.TextBox textBoxLong4;
        private System.Windows.Forms.TextBox textBoxLong5;
        private System.Windows.Forms.TextBox textBoxLong1;
        private System.Windows.Forms.ComboBox comboBoxIntensity;
        private System.Windows.Forms.TextBox textBoxHeight2;
        private System.Windows.Forms.TextBox textBoxHeight3;
        private System.Windows.Forms.TextBox textBoxHeight4;
        private System.Windows.Forms.TextBox textBoxHeight5;
        private System.Windows.Forms.TextBox textBoxHeight1;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox textBoxHeight7;
        private System.Windows.Forms.TextBox textBoxHeight8;
        private System.Windows.Forms.TextBox textBoxHeight9;
        private System.Windows.Forms.TextBox textBoxHeight10;
        private System.Windows.Forms.TextBox textBoxHeight6;
        private System.Windows.Forms.TextBox textBoxLong7;
        private System.Windows.Forms.TextBox textBoxLong8;
        private System.Windows.Forms.TextBox textBoxLong9;
        private System.Windows.Forms.TextBox textBoxLong10;
        private System.Windows.Forms.TextBox textBoxLong6;
        private System.Windows.Forms.TextBox textBoxLat7;
        private System.Windows.Forms.TextBox textBoxLat8;
        private System.Windows.Forms.TextBox textBoxLat9;
        private System.Windows.Forms.TextBox textBoxLat10;
        private System.Windows.Forms.TextBox textBoxLat6;
        private System.Windows.Forms.ComboBox comboBoxCloudId;
        private System.Windows.Forms.Label label13;
    }
}

